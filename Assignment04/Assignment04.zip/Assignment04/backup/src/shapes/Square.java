package shapes;

/**
 * Title: Square Class
 * Description: CS 235 Assignment #4 - Square - this class defines a Square object
 * @author Ricky Mutschlechner
 * @date December 11th 2012
 */

public class Square extends Rectangle {
	private static final long serialVersionUID = 1L;

	public Square(int x, int y, int size){
		super(x, y, size, size); //"Size" is the length of a side
	}
	
	/**
	 * size - returns the side length of this Square
	 * @require none
	 * @ensure none
	 */
	public int size(){
		return super.width();
	}
	
}
