package shapes;

import java.awt.Graphics;
import java.awt.Color;

/**
 * Title: DrawableTriangle class for CSIS 235 Assignment #4
 * Description: CS 235 Assignment #4 - DrawableTriangle
 *              A class that defines a DrawableTriangle - a Triangle that can be painted to the screen
 * @author Noah Muth
 * @email noah.muth@uwrf.edu
 * @author Ricky Mutschlechner
 * @email riccardo.mutschlechner@my.uwrf.edu
 * @date   December 11th 2012
 * @version 1.0
 */

public class DrawableTriangle extends Triangle implements Drawable{
    private static final long serialVersionUID = 1L;
    
    public DrawableTriangle(int x, int y, int x2, int y2, int x3, int y3) {
        super(x, y, x2, y2, x3, y3);
    }

    public void draw(Graphics g) {
    	g.setColor( java.awt.Color.BLUE );
        g.drawLine(getX_position(), getY_position(), x2, y2);
    	g.setColor(java.awt.Color.RED);
        g.drawLine(x2, y2, x3, y3);
    	g.setColor(java.awt.Color.GREEN);
        g.drawLine(getX_position(), getY_position(), x3, y3);

        int[] x = { getX_position(), x2, x3 };
        int[] y = { getY_position(), y2, y3 };
        //g.drawPolygon(x, y, 3);
    }
}
