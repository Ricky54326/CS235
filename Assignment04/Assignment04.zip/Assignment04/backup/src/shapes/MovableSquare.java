package shapes;

public class MovableSquare extends DrawableSquare implements Movable {
	
	public MovableSquare(int x, int y, int size) {
		super(x, y, size);
	}

	private static final long serialVersionUID = 1L;

	public void move(int dx, int dy) {
		moveTo(this.getX_position()+dx, this.getY_position()+dy);
	}

}
