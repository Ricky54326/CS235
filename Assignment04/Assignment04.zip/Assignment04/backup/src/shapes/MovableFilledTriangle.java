package shapes;

public class MovableFilledTriangle extends FilledTriangle implements Movable {

	public MovableFilledTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
		super(x1, y1, x2, y2, x3, y3);
	}

	/**
	 * move - moves the triangle
	 * 
	 * This is different from the other shapes because the Triangle shape tracks three points instead of just one.
	 */
	public void move(int dx, int dy) {
		moveTo(x1+dx, y1+dy);
		x2 += dx;
		y2 += dy;
		x3 += dx;
		y3 += dy;
	}
}
