package shapes;

public interface Movable {
	public abstract void move(int dx, int dy);
}
