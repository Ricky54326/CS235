package shapes;


/**
 * Title: DrawableEllipse class for CSIS 235 Assignment #4
 * Description: CS 235 Assignment #4 - MovableFilledCircle
 *              A class that defines a MovableFilledCircle - a MovableFilledCircle that can be painted to the screen
 * @author Ricky Mutschlechner
 * @date   December 11th, 2012
 * @version 1.0
 */

public class MovableFilledCircle extends FilledCircle implements Movable {
	private static final long serialVersionUID = 1L;

	public MovableFilledCircle(int x, int y, int diameter){
		super(x, y, diameter); 
	}

	@Override
	public void move(int dx, int dy) {
		moveTo(this.getX_position()+dx, this.getY_position()+dy);
	}
	
}
