package shapes;

/**
 * Title: MovableCircle class for CSIS 235 Assignment #4
 * Description: CS 235 Assignment #4 - MovableCircle
 *              A class that defines a MovableCircle - an MovableCircle that can be painted to the screen
 * @author Ricky Mutschlechner
 * @date   December 11th, 2012
 * @version 1.0
 */


public class MovableCircle extends DrawableCircle implements Movable {
	
	/**
	 * MovableCircle- an Ellipse that is able to be painted to the screen
	 * @require x >= 0, y >= 0, diameter > 1
	 * @ensure none
	 */
	public MovableCircle(int x, int y, int diameter) {
		super(x, y, diameter);
		assert x >= 0 : "x is less than 0!";
		assert y >= 0 : "y is less than 0!";
		assert diameter > 1 : "radius is less than 1!";
	}

	private static final long serialVersionUID = 1L;

	
	public void move(int dx, int dy) {
		moveTo(this.getX_position()+dx, this.getY_position()+dy);
	}

}
