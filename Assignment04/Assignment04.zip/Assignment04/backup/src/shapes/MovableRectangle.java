package shapes;

public class MovableRectangle extends DrawableRectangle implements Movable{
	
	public MovableRectangle(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

	private static final long serialVersionUID = 1L;

	public void move(int dx, int dy) {
		moveTo(this.getX_position()+dx, this.getY_position()+dy);
	}

}
